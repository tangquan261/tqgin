//
//  MsgView.h
//  zego
//
//  Created by rd on 2019/8/12.
//  Copyright © 2019年 WebView. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MsgView : UIView

@property (nonatomic, strong)NSMutableArray *array;
@end

NS_ASSUME_NONNULL_END
