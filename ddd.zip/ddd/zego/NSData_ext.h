//
//  NSData_ext.h
//  zego
//
//  Created by rd on 2019/8/21.
//  Copyright © 2019年 WebView. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSData(ext)

- (NSData *)zlibInflate;
@end

NS_ASSUME_NONNULL_END
