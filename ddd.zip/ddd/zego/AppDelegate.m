//
//  AppDelegate.m
//  zego
//
//  Created by rd on 2019/8/9.
//  Copyright © 2019年 WebView. All rights reserved.
//

#import "AppDelegate.h"
#import "AFNetworking.h"
#import "GZIP.h"
#import "NSData_ext.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    NSString *soapStr = @"";
    
    NSData *data =[soapStr dataUsingEncoding:NSUTF8StringEncoding];
    
     NSData *zlib = [data zlibInflate];
    
    NSError *error;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:zlib options:NSJSONReadingAllowFragments error:&error];
    if (dict == nil || [dict class] == [NSNull class]) {
        NSLog(@"服务器返回数据，解析失败：%@=====",error.localizedDescription);
        
    }
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    // 返回NSData
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    // 设置请求头，也可以不设置，看自己的需求解开注释，一般不需要
    //[manager.requestSerializer setValue:@"http://www.wincansoft.com/wyxsms/QueryUserID" forHTTPHeaderField:@"SOAPAction"];
    //[manager.requestSerializer setValue:@"51serapp.wincansoft.net" forHTTPHeaderField:@"Host"];
    [manager.requestSerializer setValue:[NSString stringWithFormat:@"%zd", soapStr.length] forHTTPHeaderField:@"Content-Length"];
    // 这个设置是必须的
    //[manager.requestSerializer setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer setValue:@"gzip, deflate" forHTTPHeaderField:@"Accept-Encoding"];
     manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html,application/xhtml+xml,application/xml", @"q=0.9,image/webp,image/apng,*/*", @"text/javascript", @"text/html", @"text/plain", nil];
    // [manager.requestSerializer setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    // 设置HTTPBody
    [manager.requestSerializer setQueryStringSerializationWithBlock:^NSString *(NSURLRequest *request, NSDictionary *parameters, NSError *__autoreleasing *error){
        return soapStr;
    }];
    
    NSString *hotkey = @"http://18.139.33.74/you/getHotKey.php";
    NSString *chapter = @"http://14.33.133.64/you/getChapter.php";
    NSString *search = @"http://14.33.133.64/you/search.php";
    NSString *getBook = @"http://170.178.179.106/you/getBook.php";
    
    [manager POST:getBook parameters:soapStr progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
     
        NSData *zlib = [responseObject zlibInflate];
        
        NSError *error;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:zlib options:NSJSONReadingAllowFragments error:&error];
        if (dict == nil || [dict class] == [NSNull class]) {
            NSLog(@"服务器返回数据，解析失败：%@=====",error.localizedDescription);
            
            return;
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
