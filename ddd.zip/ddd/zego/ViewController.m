//
//  ViewController.m
//  zego
//
//  Created by rd on 2019/8/9.
//  Copyright © 2019年 WebView. All rights reserved.
//

#import "ViewController.h"
#import "ZegoAudioRoom/ZegoAudioRoom.h"
#import "SVProgressHUD.h"
#import "Masonry.h"
#import "MicoView.h"
#import "MsgView.h"
#import "MsgViewController.h"


@interface ViewController ()<ZegoAudioIMDelegate,ZegoAudioRoomDelegate,
ZegoAudioLivePlayerDelegate,ZegoAudioLivePublisherDelegate,UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong)ZegoAudioRoomApi *zegoRoom;
@property (nonatomic, strong)UILabel *label;
@property (nonatomic, strong)UIButton* btnSendMsg;
@property (nonatomic, strong)UIButton* btnExit;
@property (nonatomic, strong)UIButton* btnNew;

@property (nonatomic, strong)NSMutableArray *arrayList;

@property (nonatomic, strong)UITableView *tableView;

@property (nonatomic, strong)MicoView *micView;
@property (nonatomic, strong)MsgView *msgView;
@property (nonatomic, copy)NSString *userid;
@property (nonatomic, copy)NSString *userName;


@property (nonatomic, strong)NSMutableDictionary *dicMic;

@property (nonatomic, strong)NSMutableArray *arrayMsg;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _arrayList = [NSMutableArray arrayWithCapacity:10];
    _dicMic = [NSMutableDictionary dictionaryWithCapacity:10];
    _arrayMsg = [NSMutableArray arrayWithCapacity:10];
    [self.view addSubview:self.btnSendMsg];
   
    [self.view addSubview:self.btnExit];
    [self.view addSubview:self.micView];
    [self.view addSubview:self.msgView];
    [self.view addSubview:self.btnNew];
    
    [self.btnSendMsg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).mas_offset(0);
        make.top.equalTo(self.view).mas_offset(0);
        make.size.mas_offset(CGSizeMake(100, 50));
    }];
    
    [self.btnExit mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view).mas_offset(0);
        make.size.mas_offset(CGSizeMake(100, 50));
    }];
    
    [self.btnNew mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view);
        make.top.equalTo(self.view).mas_offset(0);
        make.size.mas_offset(CGSizeMake(100, 50));
    }];
    
    [self.view addSubview:self.tableView];
     
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
    
    _userid =[NSString stringWithFormat:@"tq_%u", arc4random()];
    _userName = @"00name";
   
    [ZegoAudioRoomApi setUserID:_userid userName:_userName];
}

- (void)doActionIn:(UIButton*)sender{
    
    if ([sender.titleLabel.text isEqualToString:@"进入"]){
        [sender setTitle:@"离开" forState:UIControlStateNormal];
        [[self zegoRoom] loginRoom:@"tq001" completionBlock:^(int errorCode) {
            
          
        }];
    }
    else{
        [sender setTitle:@"进入" forState:UIControlStateNormal];
        [[self zegoRoom] logoutRoom];
        [self.arrayList removeAllObjects];
         [self.tableView reloadData];
        
        [self.dicMic removeAllObjects];
        [self.micView setDicmic:nil];
        
        [self.arrayMsg removeAllObjects];
        [self.msgView setArray:nil];
    }
}

- (void)doActionSend:(UIButton*)sender{
    NSString *msg = @"大家好";
    [self.zegoRoom sendRoomMessage:@"大家好" type:(ZEGO_TEXT) category:(ZEGO_CHAT) completion:^(int errorCode, NSString *roomId, unsigned long long messageId) {
        
        [SVProgressHUD showWithStatus:[NSString stringWithFormat:@"%u",errorCode]];
        [SVProgressHUD dismissWithDelay:1.5];
        
        if (errorCode == 0) {
            [self.arrayMsg addObject:msg];
            [self.msgView setArray:self.arrayMsg];
        }
    }];
}

- (void)doActionNewMsg:(UIButton*)sender{
    MsgViewController *pvc = [[MsgViewController alloc] init];
    //pvc.hidesBottomBarWhenPushed = YES;
    
    [self presentModalViewController:pvc animated:YES];
}

/**
 收到房间的广播消息
 
 @param roomId 房间 Id
 @param messageList 消息列表，包括消息内容，消息分类，消息类型，发送者等信息
 @discussion 调用 [ZegoAudioRoomApi (IM) -sendRoomMessage:type:category:priority:completion:] 发送消息，会触发此通知
 */
- (void)onRecvAudioRoomMessage:(NSString *)roomId messageList:(NSArray<ZegoRoomMessage*> *)messageList{
    
    for (int i = 0; i < [messageList count]; i++) {
        
        ZegoRoomMessage  *message = messageList[i];
        
        NSString *str = [NSString stringWithFormat:@"type:%u_type:%u_con:%@_from:%@",message.type, message.category,message.content,message.fromUserId];
        
        [self.arrayMsg addObject:message.content];
        [self.msgView setArray:self.arrayMsg];
        
        [SVProgressHUD showInfoWithStatus:str];
        [SVProgressHUD dismissWithDelay:1 completion:^{
            
        }];
    }
}

/**
 收到会话消息
 
 @param roomId 房间 Id
 @param conversationId 会话 Id
 @param message 会话消息，包括消息内容，消息类型，发送者，发送时间等信息
 @discussion 调用 [ZegoAudioRoomApi (IM) -sendConversationMessage:type:conversationId:completion] 发送消息，会触发此通知
 */
- (void)onRecvConversationMessage:(NSString *)roomId conversationId:(NSString *)conversationId message:(ZegoConversationMessage *)message{
    
}





/**
 用户被踢出聊天室
 
 @param reason 原因
 @param roomID 房间 ID
 @discussion 可在该回调中处理用户被踢出房间后的下一步处理（例如报错、重新登录提示等）
 */
- (void)onKickOut:(int)reason roomID:(NSString *)roomID{
    
}

/**
 与 server 断开通知
 
 @param errorCode 错误码，0 表示无错误
 @param roomID 房间 ID
 @discussion 建议开发者在此通知中进行重新登录、推/拉流、报错、友好性提示等其他恢复逻辑。与 server 断开连接后，SDK 会进行重试，重试失败抛出此错误。请注意，此时 SDK 与服务器的所有连接均会断开
 */
- (void)onDisconnect:(int)errorCode roomID:(NSString *)roomID{
    
}

/**
 流更新消息，此时sdk会开始拉流/停止拉流
 
 @param type 增加/删除流
 @param stream 流信息
 */
- (void)onStreamUpdated:(ZegoAudioStreamType)type stream:(ZegoAudioStream*)stream{
    
    if (type == ZEGO_AUDIO_STREAM_ADD) {
        [_dicMic setObject:stream forKey:stream.userID];
    }
    else{
        [_dicMic removeObjectForKey:stream.userID];
    }
    
    [self.micView setDicmic:_dicMic];
}

/**
 流附加信息更新
 
 @param streamList 附加信息更新的流列表
 @param roomID 房间 ID
 @discussion 主播推流成功后调用 [ZegoAudioRoomApi (Publisher) -updateStreamExtraInfo:] 更新附加信息，在此回调中通知房间内其他成员。调用 [ZegoAudioRoomApi (Publisher) -updateStreamExtraInfo:] 更新信息的调用方，不会收到此回调
 */
- (void)onStreamExtraInfoUpdated:(NSArray<ZegoAudioStream *> *)streamList roomID:(NSString *)roomID{
    
    for (ZegoAudioStream*stream in streamList) {
        [_dicMic setObject:stream forKey:stream.userID];
    }
     [self.micView setDicmic:_dicMic];
}

/**
 房间成员更新回调
 
 @param userList 成员更新列表
 @param type  更新类型(增量，全量)
 @discussion 当房间成员变化（例如用户进入、退出房间）时，会触发此通知
 */
- (void)onUserUpdate:(NSArray<ZegoUserState *> *)userList updateType:(ZegoUserUpdateType)type{
    
    if (type == ZEGO_UPDATE_TOTAL) {
        
        ZegoUserState *user = [[ZegoUserState alloc] init];
        user.userID = self.userid;
        user.userName = self.userName;
        [self.arrayList addObject:user];
        
        for (int i = ([userList count]-1);i >=0;i--) {
            ZegoUserState *usr = userList[i];
            [self.arrayList addObject:usr];
        }
    }
    else{
        for (ZegoUserState *usr in userList) {
            if (usr.updateFlag == ZEGO_USER_ADD) {
                [self.arrayList insertObject:usr atIndex:0];
            }
            else{
                NSMutableArray *arrayCache = [NSMutableArray arrayWithCapacity:0];
                for (ZegoUserState *old in _arrayList) {
                    if ([old.userID isEqualToString:usr.userID]) {
                        [arrayCache addObject:old];
                    }
                }
                
                if ([arrayCache count] > 0) {
                    [_arrayList removeObjectsInArray:arrayCache];
                }
                
                
            }
        }
    }
    
    
    
    [self.tableView reloadData];
}

/**
 收到自定义消息
 
 @param fromUserID 消息来源 UserID
 @param fromUserName 消息来源 UserName
 @param content 消息内容
 @param roomID 房间 ID
 @discussion 调用 [ZegoLiveRoomApi -sendCustomCommand:content:completion:] 发送自定义消息后，消息列表中的用户会收到此通知
 */
- (void)onReceiveCustomCommand:(NSString *)fromUserID userName:(NSString *)fromUserName content:(NSString*)content roomID:(NSString *)roomID{
    
}




/**
 播放流事件
 
 @param stateCode 播放状态码
 @param stream 流信息
 */
- (void)onPlayStateUpdate:(int)stateCode stream:(ZegoAudioStream *)stream{
    
}

/**
 观看质量更新
 
 @param streamID 观看流ID
 @param quality quality 参考ZegoApiPlayQuality定义
 */
- (void)onPlayQualityUpate:(NSString *)streamID quality:(ZegoApiPlayQuality)quality{
    
}


/**
 推流状态更新
 
 @param stateCode 状态码
 @param streamID 流ID
 @param info 推流信息
 */
- (void)onPublishStateUpdate:(int)stateCode streamID:(NSString *)streamID streamInfo:(NSDictionary *)info{
    
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [_arrayList count];
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    ZegoUserState *info = _arrayList[indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@_%@",info.userID, info.userName];
    
    return cell;
}


-(UILabel*)label{
    if (!_label) {
        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 20)];
        [_label setText:@"你好"];
    }
    return _label;
}

- (ZegoAudioRoomApi*)zegoRoom{
    if (!_zegoRoom) {
        
        //[ZegoAudioRoomApi setConfig:@"test"];
        [ZegoAudioRoomApi setUseTestEnv:NO];
        [ZegoAudioRoomApi setVerbose:NO];
        Byte signKey[] = {0x5e,0xe4,0xbc,0x52,0xb5,0xd8,0x04,0x2a,0x26,0x25,0x49,0x08,0x3f,0x36,0xbb,0x90,0x08,0xbe,0xaa,0xa4,0x91,0x2b,0xe0,0xc5,0x53,0x73,0x57,0x35,0x93,0x9c,0x69,0xb4};
        
        NSData *data = [NSData dataWithBytes:signKey length:32];
        _zegoRoom = [[ZegoAudioRoomApi alloc] initWithAppID:1927892782 appSignature:data];
        
        [_zegoRoom setUserStateUpdate:YES];
        [_zegoRoom setAudioRoomDelegate:self];//房间管理回调
        [_zegoRoom setManualPlay:NO];
        [_zegoRoom setManualPublish:YES];
        
        [_zegoRoom setAudioIMDelegate:self];//im回调
        [_zegoRoom setAudioPlayerDelegate:self];//播放回调
        [_zegoRoom setAudioPublisherDelegate:self];//推流回调
    }
    return _zegoRoom;
}

- (UIButton*)btnSendMsg{
    if (!_btnSendMsg) {
        _btnSendMsg = [[UIButton alloc] init];
        [_btnSendMsg setBackgroundColor:[UIColor grayColor]];
        [_btnSendMsg setTitle:@"发送" forState:UIControlStateNormal];
        [_btnSendMsg addTarget:self action:@selector(doActionSend:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _btnSendMsg;
}

- (UIButton*)btnExit{
    if (!_btnExit) {
        _btnExit = [[UIButton alloc] init];
        [_btnExit setBackgroundColor:[UIColor grayColor]];
        [_btnExit setTitle:@"进入" forState:UIControlStateNormal];
        [_btnExit addTarget:self action:@selector(doActionIn:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _btnExit;
}

- (UIButton*)btnNew{
    if (!_btnNew) {
        _btnNew = [[UIButton alloc] init];
        [_btnNew setBackgroundColor:[UIColor grayColor]];
        [_btnNew setTitle:@"消息" forState:UIControlStateNormal];
        [_btnNew addTarget:self action:@selector(doActionNewMsg:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _btnNew;
}


- (UITableView*)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 400, 200, 200) style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate= self;
        [_tableView setShowsVerticalScrollIndicator:NO];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
        [_tableView setKeyboardDismissMode:UIScrollViewKeyboardDismissModeOnDrag];
        _tableView.rowHeight = UITableViewAutomaticDimension;
        [_tableView setAllowsSelection:NO];
        if(@available(iOS 11.0, *)){
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
    }
    return  _tableView;
}

- (MicoView*)micView{
    if (!_micView) {
        _micView = [[MicoView alloc] initWithFrame:CGRectMake(0, 100, 375, 200)];
        [_micView setBlockAction:^(NSInteger nindex) {
           
            if ([self hasNindex:nindex]) {
                [SVProgressHUD showWithStatus:@"已经有人了"];
                [SVProgressHUD dismissWithDelay:1.5];
                return;
            }
            
            ZegoAudioStream *user = [self.dicMic objectForKey:self.userid];
            
            if (user) {
                //已经在mic上
                
                if ([user.extraInfo integerValue] == nindex) {
                    //下麦
                    [self.zegoRoom stopPublish];
                    [self.dicMic removeObjectForKey:self.userid];
                    
                }
                else{
                    //切换mic
                    id temp = [NSString stringWithFormat:@"%u",nindex];
                    user.extraInfo = temp;
                    [self.zegoRoom updateStreamExtraInfo:temp];
                }
            }
            else{
                bool bFalg = [self.zegoRoom startPublish];
                
                if (bFalg) {
                    id temp = [NSString stringWithFormat:@"%u",nindex];
                    ZegoAudioStream *stream = [[ZegoAudioStream alloc] init];
                    stream.userID = self.userid;
                    stream.userName = self.userName;
                    stream.extraInfo =temp;
                    [self.dicMic setObject:stream forKey:self.userid];
                    
                    [self.zegoRoom updateStreamExtraInfo:temp];
                }
            }
            
            [self.micView setDicmic:self.dicMic];
        }];
        [_micView setBackgroundColor:[UIColor grayColor]];
        
        
    }
    return _micView;
}

- (BOOL)hasNindex:(NSInteger)nindex{
    
    for (id key in self.dicMic) {
        
        ZegoAudioStream *user = [self.dicMic objectForKey:key];
        if (nindex == [user.extraInfo integerValue] && ![user.userID isEqualToString:self.userid]) {
            return YES;
        }
    }
    return NO;
}

- (MsgView*)msgView{
    if(!_msgView){
        _msgView = [[MsgView alloc] initWithFrame:CGRectMake(210, 350,375-205, 250)];
        [_msgView setBackgroundColor:[UIColor grayColor]];
    }
    return _msgView;
}
    
    @end
